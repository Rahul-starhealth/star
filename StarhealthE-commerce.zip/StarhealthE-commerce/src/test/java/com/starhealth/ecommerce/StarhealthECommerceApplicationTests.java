package com.starhealth.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarhealthECommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
