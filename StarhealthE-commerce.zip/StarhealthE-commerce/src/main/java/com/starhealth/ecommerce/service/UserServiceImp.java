package com.starhealth.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecommerce.entity.User;
import com.starhealth.ecommerce.repository.IUser;
@Service
public class UserServiceImp implements UserService {
	@Autowired
	IUser userrepo;

	@Override
	public User addUser(User user) {
		return userrepo.save(user);

	}

	@Override
	public User getUserByName(String userName, String domin) {
		return userrepo.getUserByName(userName,domin) ;
	}

}
