package com.starhealth.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.ecommerce.entity.Cart;

public interface ICart extends JpaRepository<Cart, Integer> {
	

}
