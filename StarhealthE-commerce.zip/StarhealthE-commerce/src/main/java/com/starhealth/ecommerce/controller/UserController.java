package com.starhealth.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.ecommerce.entity.User;
import com.starhealth.ecommerce.service.UserService;

@RestController
@RequestMapping("/api/v1/starhealth")
public class UserController {
	@Autowired
	UserService userservice;
	
	@PostMapping("/add")
	public User addUser(@RequestBody User user) {
		return userservice.addUser(user);
	}
	
	@GetMapping("/get/{userName}/{role}")
	public User getUserbyName(@PathVariable String userName,String role) {
		return userservice.getUserByName(userName, role);
	}
	
	

}
