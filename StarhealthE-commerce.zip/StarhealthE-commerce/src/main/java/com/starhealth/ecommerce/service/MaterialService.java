package com.starhealth.ecommerce.service;

import java.util.List;

import com.starhealth.ecommerce.entity.Material;

public interface MaterialService {
	
	public Material addProduct(Material prod);
	public Material updateProduct(Material prod);
	public Material getProductById(int id);
	public List<Material> getAllProducts();
	public void deleteProductById(int id);
	
	
}
