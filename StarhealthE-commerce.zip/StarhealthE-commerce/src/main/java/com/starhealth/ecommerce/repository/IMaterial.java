package com.starhealth.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.ecommerce.entity.Material;

public interface IMaterial extends JpaRepository<Material, Integer>{

}
