package com.starhealth.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecommerce.entity.Material;
import com.starhealth.ecommerce.repository.IMaterial;
@Service
public class MaterialServiceImp implements MaterialService {
	
	@Autowired
	IMaterial prodrepo;
	
	@Override
	public Material addProduct(Material prod) {
		return prodrepo.save(prod);
	}

	@Override
	public Material updateProduct(Material prod) {
		// TODO Auto-generated method stub
		return prodrepo.save(prod);
	}
	@Override
	public Material getProductById(int id) {
		// TODO Auto-generated method stub
		return prodrepo.findById(id).orElse(new Material()) ;
	}
	@Override
	public List<Material> getAllProducts() {
		// TODO Auto-generated method stub
		return prodrepo.findAll();
	}
	@Override
	public void deleteProductById(int id) {
		// TODO Auto-generated method stub
		prodrepo.deleteById(id); 
	}
	



}
