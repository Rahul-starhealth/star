package com.starhealth.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.ecommerce.entity.Cart;
import com.starhealth.ecommerce.service.CartService;

@RestController
@RequestMapping("/api/v1/starhealth_db")
@CrossOrigin("http://localhost:4200/")
public class CartController {
	@Autowired
	CartService CartService;
	
	@PostMapping("/addCartProduct")
	public Cart addProduct (@RequestBody Cart Cart) {
		return CartService.addCart(Cart);
	}
	@PutMapping("/updateCartProduct")
	public Cart updateProduct(@RequestBody Cart Cart) {
		return CartService.addCart(Cart);
	}
	
	@GetMapping("/getCartProductById")
	public Cart getProductById(@PathVariable int id) {
		return CartService.getCartProductById(id);
		
	}
	@GetMapping("/ getAllCartProducts")
	public List<Cart> getAllProducts(){
		return CartService.getAllCartProducts();
	}
	@DeleteMapping("/deleteCartproductbyid/{id}")
	public void deleteProductById(@PathVariable int id) {
		 CartService.deleteCartProductById(id);
		
	}

}
