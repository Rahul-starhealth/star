import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './Product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

   constructor(private http:HttpClient) { }


   url:string = "http://localhost:8080/api/v1";

  getAllProducts():Observable<Product[]>{

   return   this.http.get<Product[]>(this.url+'/getAllProducts');  
  }

  addProduct(productObj:Product){
    return this.http.post<Product>(this.url+'/addProduct',productObj).subscribe((data:Product)=>{console.log('data from post '+data)})

  }
  //  deleteById(id:number):Observable<string>{

  //  // alert('delete from service '+id)

  //    return   this.http.delete<string>(this.url+'/delete/'+id);

  // }

   updateProduct(updateObj:Product){

   return   this.http.put<Product>(this.url+'/updateProduct',updateObj).subscribe((data:Product)=>console.log(data));

  }

 deleteProductById(id:number):Observable<string>{

   // alert('delete from service '+id)

     return   this.http.delete<string>(this.url+'/deleteProduct/'+id);

  }

}
